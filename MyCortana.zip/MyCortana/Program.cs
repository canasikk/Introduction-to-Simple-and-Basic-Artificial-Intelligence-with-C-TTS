﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Recognition;
using System.IO;
using System.Runtime.InteropServices;
using System.Speech.Synthesis;
using SpeechLib;
using System.Media;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace MyCortana
{
    internal class Program
    {
        //Global Var
        private static SpeechRecognitionEngine sr = new SpeechRecognitionEngine();
        private static Grammar g = new DictationGrammar();
        private static RecognitionResult res;
        private static Learning learn = new Learning(System.AppContext.BaseDirectory + "\\cmd.ini");
        private static SoundPlayer player = new SoundPlayer();
        private static string path = System.AppContext.BaseDirectory + "listen.wav";
        //Global Var
        
        static void Main(string[] args)
        {

          



            Random rand = new Random();
            SpVoice voice = new SpVoice();
            voice.Speak(learn.Read("BasicStatus", rand.Next(5).ToString()), SpeechVoiceSpeakFlags.SVSFDefault);




            sr.LoadGrammar(g);
            WaitingSound();
            while (true)
            {
                try
                {
                    
                    sr.SetInputToDefaultAudioDevice();
                    res = sr.Recognize();

                    Console.WriteLine(res.Text);
                    learn.Write("Words", res.Text, res.Text);

                    if (res.Text == "Search" || res.Text == "search")
                    {
                        WaitingSound();
                        Console.Write("Waiting...");
                        sr.SetInputToDefaultAudioDevice();
                        res = sr.Recognize();
                        SearchNet(res.Text);
                        Console.Clear();
                    }
                    if (res.Text == "Start" || res.Text == "start")
                    {
                        WaitingSound();
                        Console.WriteLine("Waiting...");
                        sr.SetInputToDefaultAudioDevice();
                        res = sr.Recognize();
                        StartApp(res.Text);
                        Console.Clear();
                    }
                    if (res.Text == "Screenshots" || res.Text == "screenshots" || res.Text == "ss" ||  res.Text =="take")
                    {
                        Bitmap Screenshot = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
                        Graphics GFX = Graphics.FromImage(Screenshot);
                        GFX.CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size);
                        Screenshot.Save(System.AppContext.BaseDirectory + DateTime.Now.ToString().Replace("/", "_").Replace(":", "_") + ".jpg", ImageFormat.Jpeg);
                        Console.Clear();
                    }

                }
                catch (Exception ex)
                {
                    Console.Write(ex.ToString());
                }
            }





            Console.ReadKey();
        }

        private static void SearchNet(string resLink)
        {
            try
            {
                System.Diagnostics.Process.Start("https://www.google.com.tr/search?q=" + resLink);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
        }
        private static void StartApp(string resPath)
        {
            try
            {
                string app = learn.Read("Path", resPath);
                System.Diagnostics.Process.Start('"' + app + '"');
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
        }
        private static void WaitingSound()
        {
            player.Stop();
            player.SoundLocation = path;
            player.Play();
        }
    }
}